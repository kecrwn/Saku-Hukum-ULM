import os
import requests

GROQ_API_KEY = "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"

url = "https://api.groq.com/openai/v1/chat/completions"
headers = {
    "Authorization": f"Bearer {GROQ_API_KEY}",
    "Content-Type": "application/json"
}

data = {
    "model": "openai/gpt-oss-120b",
    "messages": [
        {"role": "user", "content": "Hello, testing 1 2 3"}
    ]
}

try:
    resp = requests.post(url, headers=headers, json=data)
    print(resp.status_code)
    print(resp.json())
except Exception as e:
    print(e)
