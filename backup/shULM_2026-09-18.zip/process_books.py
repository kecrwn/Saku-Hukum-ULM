import os
import requests
import json
import glob
from concurrent.futures import ThreadPoolExecutor

GROQ_API_KEY = "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"

def simplify_text(text, lang="id"):
    if not text or not text.strip(): return text, True
    
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    
    sys_prompt = """You are a Book Simplifier agent for the Saku Hukum ULM project.
Your task is to simplify the language of this law textbook section for a 1st-year, 1st-semester law student.
Rules:
1. Simplify language and sentence structure so it's approachable, but NOT dumbed-down.
2. DO NOT CHANGE any factual, legal, or substantive content.
3. Apply full rich text formatting in Markdown (bold, italic, strikethrough, etc.).
4. Format types: Body text as normal paragraphs. Bullet/numbered lists as Markdown lists. Quotes as Markdown blockquotes (`>`). Legal citations/references MUST BE wrapped in `<cite>` tags (e.g. `<cite>Pasal 1 KUHP</cite>`).
5. Output ONLY the simplified markdown text. Do not wrap in ```markdown or include intro text."""

    data = {
        "model": "openai/gpt-oss-120b",
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": f"Simplify this text in {'Indonesian' if lang == 'id' else 'English'}:\n\n{text}"}
        ],
        "temperature": 0.3
    }
    
    try:
        resp = requests.post(url, headers=headers, json=data)
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"].strip(), True
        else:
            print(f"Error from Groq: {resp.text}")
            return text, False
    except Exception as e:
        print(f"Exception: {e}")
        return text, False

def process_file(filepath):
    print(f"Processing {filepath}...")
    with open(filepath, 'r') as f:
        data = json.load(f)
        
    changed = False
    
    if "chapters" in data:
        for idx, chapter in enumerate(data["chapters"]):
            if "content" in chapter and chapter["content"].strip():
                new_text, success = simplify_text(chapter["content"], "id")
                if success and new_text != chapter["content"]:
                    chapter["content"] = new_text
                    changed = True
            
            if "contentEn" in chapter and chapter["contentEn"].strip():
                new_text, success = simplify_text(chapter["contentEn"], "en")
                if success and new_text != chapter["contentEn"]:
                    chapter["contentEn"] = new_text
                    changed = True
            
            # strip out _processed if it exists from previous run
            if "_processed" in chapter: del chapter["_processed"]
            if "_processedEn" in chapter: del chapter["_processedEn"]
            
    elif "sections" in data:
        for idx, section in enumerate(data["sections"]):
            if "contentId" in section and section["contentId"].strip():
                new_text, success = simplify_text(section["contentId"], "id")
                if success and new_text != section["contentId"]:
                    section["contentId"] = new_text
                    changed = True
            
            if "contentEn" in section and section["contentEn"].strip():
                new_text, success = simplify_text(section["contentEn"], "en")
                if success and new_text != section["contentEn"]:
                    section["contentEn"] = new_text
                    changed = True
                    
            if "_processedId" in section: del section["_processedId"]
            if "_processedEn" in section: del section["_processedEn"]

    if changed:
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"Saved {filepath}")
    else:
        print(f"No changes needed for {filepath}")

if __name__ == "__main__":
    files = glob.glob("src/lib/books/*.json") + glob.glob("src/lib/knowledge/*.json")
    # exclude index.ts and layout stuff
    files = [f for f in files if f.endswith(".json")]
    
    with ThreadPoolExecutor(max_workers=3) as executor:
        executor.map(process_file, files)
    
    print("All files processed.")
